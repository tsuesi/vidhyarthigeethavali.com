<div class="header  py-7 py-lg-8" >
    <div class="container">
        <div class="header-body text-center mb-7">

        </div>
    </div>

</div>
<?php /**PATH /home/u554892978/domains/otrixcommerce.in/public_html/development/resources/views/auth/layouts/headers/guest.blade.php ENDPATH**/ ?>