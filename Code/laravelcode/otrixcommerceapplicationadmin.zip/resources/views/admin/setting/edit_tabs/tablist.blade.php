<div class="nav-wrapper">
    <ul role="tablist" id="tablist" class="nav nav-pills nav-tabs nav-fill">
        <li class="nav-item">
            <a data-toggle="tab" role="tab" data-tabname="tab-store" href="#tab-store" class="nav-link active" aria-selected="true">
                <div>Store</div>
            </a>
        </li>
        <li class="nav-item">
            <a data-toggle="tab" role="tab" data-tabname="tab-general" href="#tab-general" class="nav-link">
                <div>General</div>
            </a>
        </li>
        <!-- <li class="nav-item">
            <a data-toggle="tab" role="tab" data-tabname="tab-option" href="#tab-option" class="nav-link">
                <div>Option</div>
            </a>
        </li> -->

        <li class="nav-item">
            <a data-toggle="tab" role="tab" data-tabname="tab-image" href="#tab-image" class="nav-link">
                <div>Image</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" role="tab" data-tabname="tab-mail" href="#tab-mail" class="nav-link">
                <div>Mail</div>
            </a>
        </li>

        <li class="nav-item">
            <a data-toggle="tab" role="tab" data-tabname="tab-server" href="#tab-server" class="nav-link">
                <div>Server</div>
            </a>
        </li>
    </ul>
</div>
