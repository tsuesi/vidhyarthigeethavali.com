<footer class="footer">
    @include('admin.layouts.footers.nav')
</footer>
