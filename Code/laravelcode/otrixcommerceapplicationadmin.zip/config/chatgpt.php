<?php
return [
    'ENABLE_CHATGPT'=> 'true',
    'CHATGPT_API_KEY' => 'true'
];
