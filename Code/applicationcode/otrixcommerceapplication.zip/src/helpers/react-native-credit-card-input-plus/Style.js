'use strict'
import {StyleSheet} from 'react-native'

export default StyleSheet.create({
  flipCard: {
    flex: 1,
  },

  face: {
    flex: 1
  },

  back: {
    flex: 1
  }
})