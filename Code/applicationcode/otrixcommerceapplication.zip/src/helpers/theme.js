import Colors from "./Colors";
import DarkModeColors from "./DarkModeColors";

export default {Colors,DarkModeColors};