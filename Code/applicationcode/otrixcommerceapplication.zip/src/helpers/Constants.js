// Async Store data key name
export const ASYNC_KEY = {

};
