
const MostSearchArr = [
    'Smart Watch', 'Shoes', 'Bag', 'Cap', 'Sun Glass', 'Mac', 'Shirts for Men', 'Perfume', 'Cloths'
];

export default MostSearchArr;
