const PriceList = [
    { id: "p11", name: 'under $49', value: '49' },
    { id: "p15", name: 'Under $99', value: '99' },
    { id: "p13", name: 'Under $149', value: '149' },
    { id: "p14", name: 'Under $199', value: '199' },
    { id: "p12", name: 'Under $249', value: '249' },
    { id: "p16", name: 'Under $299', value: '299' },
    { id: "p17", name: 'Under $349', value: '349' },
    { id: "p20", name: 'Under $499', value: '499' },
    { id: "p18", name: 'Under $599', value: '599' },

];

export default PriceList;
