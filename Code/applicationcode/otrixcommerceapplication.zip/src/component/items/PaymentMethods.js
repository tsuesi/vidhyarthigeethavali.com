const PaymentMethods = [
    { id: "1", name: 'Credit / Debit / ATM Card', value: 'creditCard' },
    { id: "2", name: "Cash On Delivery", value: 'cod' }
];

export default PaymentMethods;
