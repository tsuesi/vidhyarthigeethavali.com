const RateList = [
    { id: "21", name: '1 Star', value: '1' },
    { id: "22", name: '2 Star', value: '2' },
    { id: "23", name: '3 Star', value: '3' },
    { id: "24", name: '4 Star', value: '4' },
    { id: "25", name: '5 Star', value: '5' },

];

export default RateList;
